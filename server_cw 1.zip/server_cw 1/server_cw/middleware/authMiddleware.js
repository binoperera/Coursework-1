function isAuthenticated(req, res, next) {
  if (req.session.userId) {
    return next();
  }
  res.redirect('/login.html');
}

function apiKeyAuth(req, res, next) {
  const apiKey = req.query.api_key;
  if (!apiKey) {
    return res.status(403).json({
      success: false,
      message: 'API key is required'
    });
  }
  req.apiKey = apiKey;
  next();
}

module.exports = {
  isAuthenticated,
  apiKeyAuth
};