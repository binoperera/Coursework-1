const { dbGet, dbAll, dbRun } = require('../config/db');

class User {
  static async findByUsername(username) {
    const row = await dbGet('SELECT * FROM users WHERE username = ?', [username]);
    return row || null;
  }

  static async findById(id) {
    const row = await dbGet('SELECT * FROM users WHERE id = ?', [id]);
    return row || null;
  }

  static async findByApiKey(apiKey) {
    const row = await dbGet('SELECT * FROM users WHERE api_key = ?', [apiKey]);
    return row || null;
  }

  static async create(username, hashedPassword) {
    const result = await dbRun(
      'INSERT INTO users (username, password) VALUES (?, ?)',
      [username, hashedPassword]
    );
    return result.lastID;
  }

  static async updateApiKey(userId, apiKey) {
    await dbRun('UPDATE users SET api_key = ? WHERE id = ?', [apiKey, userId]);
    return apiKey;
  }
}

module.exports = User;