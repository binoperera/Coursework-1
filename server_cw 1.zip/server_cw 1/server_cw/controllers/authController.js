const User = require('../models/userModel');
const { hashPassword, comparePassword, generateApiKey } = require('../utils');

exports.register = async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Username and password are required'
    });
  }

  try {
    // Check if user already exists
    const existingUser = await User.findByUsername(username);
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: 'Username already exists'
      });
    }

    const hashed = await hashPassword(password);
    await User.create(username, hashed);
    
    res.redirect('/login.html');
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({
      success: false,
      message: 'An error occurred during registration'
    });
  }
};

exports.login = async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'Username and password are required'
    });
  }

  try {
    const user = await User.findByUsername(username);
    
    if (!user || !(await comparePassword(password, user.password))) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    req.session.userId = user.id;
    res.redirect('/dashboard.html');
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({
      success: false,
      message: 'An error occurred during login'
    });
  }
};

exports.getApiKey = async (req, res) => {
  const userId = req.session.userId;
  
  if (!userId) {
    return res.status(403).json({
      success: false,
      message: 'Unauthorized'
    });
  }

  try {
    const newKey = generateApiKey();
    await User.updateApiKey(userId, newKey);
    
    res.json({
      success: true,
      apiKey: newKey
    });
  } catch (err) {
    console.error('API key generation error:', err);
    res.status(500).json({
      success: false,
      message: 'An error occurred while generating API key'
    });
  }
};

exports.logout = (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'Failed to logout'
      });
    }
    res.redirect('/login.html');
  });
};