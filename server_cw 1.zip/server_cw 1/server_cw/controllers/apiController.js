const User = require('../models/userModel');
const axios = require('axios');

exports.getCountries = async (req, res) => {
  const apiKey = req.apiKey;

  try {
    const user = await User.findByApiKey(apiKey);
    if (!user) {
      return res.status(403).json({
        success: false,
        message: 'Invalid API key'
      });
    }

    const { data } = await axios.get('https://restcountries.com/v3.1/all');
    const filtered = data.map(c => ({
      name: c.name.common,
      capital: c.capital?.[0] || 'N/A',
      currency: Object.keys(c.currencies || {})[0] || 'N/A',
      languages: Object.values(c.languages || {}).join(', ') || 'N/A',
      flag: c.flags?.svg || 'N/A',
      population: c.population || 0
    }));
    
    res.json({
      success: true,
      count: filtered.length,
      data: filtered
    });
  } catch (err) {
    console.error('API error:', err);
    res.status(500).json({
      success: false,
      message: 'An error occurred while fetching country data'
    });
  }
};