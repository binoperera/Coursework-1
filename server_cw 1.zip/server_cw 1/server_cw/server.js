const app = require('./app');
const http = require('http');

// Try to use the specified port, or increment until finding an available one
let PORT = process.env.PORT || 3000;
const MAX_PORT_ATTEMPTS = 10;
let attempts = 0;

function startServer(port) {
  const server = http.createServer(app);
  
  server.listen(port);
  
  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE' && attempts < MAX_PORT_ATTEMPTS) {
      console.log(`Port ${port} is in use, trying ${port + 1}...`);
      attempts++;
      server.close();
      startServer(port + 1);
    } else {
      console.error('Server error:', err);
    }
  });
  
  server.on('listening', () => {
    const addr = server.address();
    console.log(`Server running on http://localhost:${addr.port}`);
  });
}

startServer(PORT);