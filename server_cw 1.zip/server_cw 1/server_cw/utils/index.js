const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

const hashPassword = async (password) => await bcrypt.hash(password, 10);
const comparePassword = async (password, hash) => await bcrypt.compare(password, hash);
const generateApiKey = () => uuidv4();

module.exports = { hashPassword, comparePassword, generateApiKey };