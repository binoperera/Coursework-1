async function getApiKey() {
  try {
    const res = await fetch('/auth/apikey');
    const data = await res.json();
    
    if (data.success) {
      document.getElementById('key').textContent = data.apiKey;
    } else {
      document.getElementById('key').textContent = 'Error loading API key';
      console.error(data.message);
    }
  } catch (error) {
    document.getElementById('key').textContent = 'Error loading API key';
    console.error('Failed to fetch API key:', error);
  }
}

function logout() {
  window.location.href = '/auth/logout';
}